CMAKE_VS_SDK_EXCLUDE_DIRECTORIES
--------------------------------

This variable allows to override Visual Studio default Exclude Directories.
