CMAKE_HOST_APPLE
----------------

``True`` for Apple OS X operating systems.

Set to ``true`` when the host system is Apple OS X.
