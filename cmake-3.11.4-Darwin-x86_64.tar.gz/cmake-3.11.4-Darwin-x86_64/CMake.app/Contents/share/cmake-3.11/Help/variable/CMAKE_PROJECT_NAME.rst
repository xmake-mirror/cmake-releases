CMAKE_PROJECT_NAME
------------------

The name of the current project.

This specifies name of the current project from the closest inherited
:command:`project` command.
