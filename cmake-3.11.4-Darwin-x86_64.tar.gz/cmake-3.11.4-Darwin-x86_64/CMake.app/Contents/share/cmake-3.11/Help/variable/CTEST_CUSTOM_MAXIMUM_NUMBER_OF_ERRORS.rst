CTEST_CUSTOM_MAXIMUM_NUMBER_OF_ERRORS
-------------------------------------

The maximum number of errors in a single build step which will be detected.
After this, the :command:`ctest_test` command will truncate the output.
Defaults to 50.

.. include:: CTEST_CUSTOM_XXX.txt
