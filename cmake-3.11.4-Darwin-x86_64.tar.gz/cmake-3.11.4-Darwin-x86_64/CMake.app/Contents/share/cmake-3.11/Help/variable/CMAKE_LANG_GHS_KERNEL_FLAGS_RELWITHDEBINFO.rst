CMAKE_<LANG>_GHS_KERNEL_FLAGS_RELWITHDEBINFO
--------------------------------------------

This variable is the ``RelWithDebInfo`` variant of the
:variable:`CMAKE_<LANG>_GHS_KERNEL_FLAGS_<CONFIG>` variable.
