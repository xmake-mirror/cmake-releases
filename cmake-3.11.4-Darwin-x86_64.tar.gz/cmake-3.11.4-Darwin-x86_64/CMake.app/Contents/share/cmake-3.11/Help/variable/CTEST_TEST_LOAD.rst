CTEST_TEST_LOAD
---------------

Specify the ``TestLoad`` setting in the :ref:`CTest Test Step`
of a :manual:`ctest(1)` dashboard client script.  This sets the
default value for the ``TEST_LOAD`` option of the :command:`ctest_test`
command.
