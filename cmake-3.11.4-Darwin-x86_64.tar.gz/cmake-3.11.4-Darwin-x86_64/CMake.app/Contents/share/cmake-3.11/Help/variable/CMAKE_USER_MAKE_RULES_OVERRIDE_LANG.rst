CMAKE_USER_MAKE_RULES_OVERRIDE_<LANG>
-------------------------------------

Specify a CMake file that overrides platform information for ``<LANG>``.

This is a language-specific version of
:variable:`CMAKE_USER_MAKE_RULES_OVERRIDE` loaded only when enabling language
``<LANG>``.
