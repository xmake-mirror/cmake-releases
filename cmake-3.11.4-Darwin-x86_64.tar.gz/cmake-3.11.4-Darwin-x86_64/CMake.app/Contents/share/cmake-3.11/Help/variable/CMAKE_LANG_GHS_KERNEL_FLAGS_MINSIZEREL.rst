CMAKE_<LANG>_GHS_KERNEL_FLAGS_MINSIZEREL
----------------------------------------

This variable is the ``MinSizeRel`` variant of the
:variable:`CMAKE_<LANG>_GHS_KERNEL_FLAGS_<CONFIG>` variable.
