CTEST_MEMORYCHECK_SUPPRESSIONS_FILE
-----------------------------------

Specify the CTest ``MemoryCheckSuppressionFile`` setting
in a :manual:`ctest(1)` dashboard client script.
