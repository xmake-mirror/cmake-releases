CMAKE_<LANG>_GHS_KERNEL_FLAGS_RELEASE
-------------------------------------

This variable is the ``Release`` variant of the
:variable:`CMAKE_<LANG>_GHS_KERNEL_FLAGS_<CONFIG>` variable.
