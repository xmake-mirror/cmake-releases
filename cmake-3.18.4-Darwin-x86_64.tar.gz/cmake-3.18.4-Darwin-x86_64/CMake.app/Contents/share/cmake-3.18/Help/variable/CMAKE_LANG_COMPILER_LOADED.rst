CMAKE_<LANG>_COMPILER_LOADED
----------------------------

Defined to true if the language is enabled.

When language ``<LANG>`` is enabled by :command:`project` or
:command:`enable_language` this variable is defined to ``1``.
