CMAKE_<LANG>_FLAGS_<CONFIG>
---------------------------

Flags for language ``<LANG>`` when building for the ``<CONFIG>`` configuration.
