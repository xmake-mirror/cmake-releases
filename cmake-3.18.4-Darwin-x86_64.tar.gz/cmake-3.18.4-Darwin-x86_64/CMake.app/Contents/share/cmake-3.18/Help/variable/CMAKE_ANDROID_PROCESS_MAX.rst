CMAKE_ANDROID_PROCESS_MAX
-------------------------

Default value for the :prop_tgt:`ANDROID_PROCESS_MAX` target property.
See that target property for additional information.
