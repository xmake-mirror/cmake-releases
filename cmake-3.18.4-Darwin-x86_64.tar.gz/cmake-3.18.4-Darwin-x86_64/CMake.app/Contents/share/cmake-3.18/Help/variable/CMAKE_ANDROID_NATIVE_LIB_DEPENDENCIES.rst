CMAKE_ANDROID_NATIVE_LIB_DEPENDENCIES
-------------------------------------

Default value for the :prop_tgt:`ANDROID_NATIVE_LIB_DEPENDENCIES` target
property.  See that target property for additional information.
