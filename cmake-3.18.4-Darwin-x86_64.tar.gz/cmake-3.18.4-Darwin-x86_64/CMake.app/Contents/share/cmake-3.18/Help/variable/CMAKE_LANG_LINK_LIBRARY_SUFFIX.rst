CMAKE_<LANG>_LINK_LIBRARY_SUFFIX
--------------------------------

Language-specific suffix for libraries that you link to.

The suffix to use for the end of a library filename, ``.lib`` on Windows.
