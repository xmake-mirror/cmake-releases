CMAKE_Swift_MODULE_DIRECTORY
----------------------------

Swift module output directory.

This variable is used to initialise the :prop_tgt:`Swift_MODULE_DIRECTORY`
property on all the targets.  See the target property for additional
information.
